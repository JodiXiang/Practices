# 入梦谣 简易试玩版

这是一个非常简单的本地试玩版本。它保留了模型设置，可以填写女娲或其他 OpenAI-compatible API。

它保留：

- 三方聊天流
- 系统按钮
- 气息、信任、觉察、自主数值
- 简短焚稿剧情
- 模型设置：Base URL / API Key / Model

它去掉：

- 英文模式
- 动态结局
- 复杂循环与穿书设定

## 启动

需要先安装 Node.js 20 或更新版本：https://nodejs.org/

Mac 双击：

```text
start-mac.command
```

Windows 双击：

```text
start-windows.bat
```

然后打开：

```text
http://127.0.0.1:4174/
```

## 模型设置

点击右上角齿轮，填写：

- Base URL：例如 `https://api.nuwaflux.com/v1`
- API Key：你的通用 key
- Model：例如 `deepseek-flash`，或女娲后台实际显示可用的模型名

如果模型调用失败，游戏会自动回退到本地固定回复。
