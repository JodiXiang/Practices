import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = fileURLToPath(new URL(".", import.meta.url));
const port = Number(process.env.PORT || 4174);
const host = process.env.HOST || "0.0.0.0";

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".md": "text/markdown; charset=utf-8"
};

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://${req.headers.host}`);

    if (req.method === "POST" && url.pathname === "/api/simple/test-model") {
      const body = await readJson(req);
      sendJson(res, 200, await testModel(body.model_config));
      return;
    }

    if (req.method === "POST" && url.pathname === "/api/simple/turn") {
      const body = await readJson(req);
      sendJson(res, 200, await generateTurn(body));
      return;
    }

    if (req.method !== "GET") {
      sendJson(res, 405, { ok: false, error: "Method not allowed" });
      return;
    }

    const requestedPath = url.pathname === "/" ? "/index.html" : decodeURIComponent(url.pathname);
    const safePath = normalize(requestedPath).replace(/^(\.\.[/\\])+/, "");
    const filePath = join(__dirname, safePath);
    if (!filePath.startsWith(__dirname)) {
      sendJson(res, 403, { ok: false, error: "Forbidden" });
      return;
    }

    const content = await readFile(filePath);
    res.writeHead(200, {
      "Content-Type": mimeTypes[extname(filePath)] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(content);
  } catch (error) {
    if (error?.code === "ENOENT") {
      sendJson(res, 404, { ok: false, error: "Not found" });
      return;
    }
    sendJson(res, 500, { ok: false, error: error instanceof Error ? error.message : "Unknown error" });
  }
});

server.listen(port, host, () => {
  console.log(`入梦谣简易版: http://127.0.0.1:${port}`);
});

async function readJson(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

function sendJson(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

async function testModel(config) {
  const modelConfig = resolveModelConfig(config);
  const validation = validateModelConfig(modelConfig);
  if (!validation.ok) return validation;

  const endpoint = buildChatCompletionsUrl(modelConfig.baseUrl);
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${modelConfig.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelConfig.model,
      messages: [{ role: "user", content: "Return exactly: OK" }],
      temperature: 0,
      max_tokens: 20
    })
  });

  if (!response.ok) {
    const text = await response.text();
    return { ok: false, error: `${response.status} ${text.slice(0, 300)}` };
  }

  return { ok: true, model: modelConfig.model };
}

async function generateTurn(body) {
  const modelConfig = resolveModelConfig(body.model_config);
  const validation = validateModelConfig(modelConfig);
  if (!validation.ok) return validation;

  const endpoint = buildChatCompletionsUrl(modelConfig.baseUrl);
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${modelConfig.apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelConfig.model,
      messages: [
        {
          role: "system",
          content: [
            "你是一个极简《入梦谣》文本游戏的回合生成器，只输出 JSON。",
            "当前场景：红楼梦第九十七回附近，潇湘馆夜半，黛玉焚稿前后。玩家是只有黛玉能看见的人。",
            "本版本只做简单体验：不要展开复杂穿书循环设定，不要改命，不要复活，不要阻止婚礼。",
            "黛玉气息很弱，说话要短，病弱、克制、自然，不要现代网络词。",
            "其他人看不见玩家。",
            "输出 schema：{\"world_text\":\"世界消息\",\"daiyu_text\":\"黛玉回应\"}。不要 Markdown，不要解释。"
          ].join("\n")
        },
        {
          role: "user",
          content: JSON.stringify({
            player_text: body.player_text,
            turn: body.turn,
            values: body.values,
            fallback_world: body.fallback_world,
            fallback_daiyu: body.fallback_daiyu
          })
        }
      ],
      temperature: 0.55,
      max_tokens: 500
    })
  });

  if (!response.ok) {
    const text = await response.text();
    return { ok: false, error: `${response.status} ${text.slice(0, 300)}` };
  }

  const data = await response.json();
  const raw = data?.choices?.[0]?.message?.content || "";
  try {
    const parsed = parseJsonFromModel(raw);
    return {
      ok: true,
      world_text: cleanText(parsed.world_text || body.fallback_world || ""),
      daiyu_text: cleanDaiyu(parsed.daiyu_text || body.fallback_daiyu || "")
    };
  } catch {
    return { ok: false, error: "Model did not return valid JSON." };
  }
}

function resolveModelConfig(config = {}) {
  return {
    apiKey: String(config.apiKey || "").trim(),
    baseUrl: String(config.baseUrl || "https://api.nuwaflux.com/v1").trim(),
    model: String(config.model || "deepseek-flash").trim()
  };
}

function validateModelConfig(config) {
  if (!config.apiKey) return { ok: false, error: "API Key is empty." };
  if (!/^[\x20-\x7e]+$/.test(config.apiKey)) {
    return { ok: false, error: "API Key 含有中文、全角字符或不可见字符，请重新复制。" };
  }
  return { ok: true };
}

function buildChatCompletionsUrl(baseUrl) {
  const trimmed = String(baseUrl || "").trim().replace(/\/$/, "");
  if (trimmed.endsWith("/chat/completions")) return trimmed;
  return `${trimmed}/chat/completions`;
}

function parseJsonFromModel(raw) {
  const text = String(raw || "").trim();
  if (!text) throw new Error("Empty response");
  try {
    return JSON.parse(text);
  } catch {
    const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (fenced?.[1]) return JSON.parse(fenced[1].trim());
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start >= 0 && end > start) return JSON.parse(text.slice(start, end + 1));
    throw new Error("No JSON object");
  }
}

function cleanText(text) {
  return String(text || "").trim().slice(0, 260);
}

function cleanDaiyu(text) {
  const replacements = new Map([
    ["系统", "此事"],
    ["任务", "此事"],
    ["玩家", "你"],
    ["AI", "幻影"],
    ["NPC", "旁人"],
    ["攻略", "谋算"],
    ["数值", "分寸"],
    ["快穿", "异梦"]
  ]);
  let output = cleanText(text);
  for (const [from, to] of replacements) output = output.replaceAll(from, to);
  return output.slice(0, 220);
}
