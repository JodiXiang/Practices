#!/bin/zsh
cd "$(dirname "$0")"
echo "Starting 入梦谣简易版..."
echo "If the browser does not open automatically, visit:"
echo "http://127.0.0.1:4174/"
open "http://127.0.0.1:4174/" >/dev/null 2>&1 &
npm start
