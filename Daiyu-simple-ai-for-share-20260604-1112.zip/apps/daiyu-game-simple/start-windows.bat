@echo off
cd /d "%~dp0"
echo Starting 入梦谣简易版...
echo If the browser does not open automatically, visit:
echo http://127.0.0.1:4174/
start http://127.0.0.1:4174/
npm start
pause
