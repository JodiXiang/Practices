const state = {
  turn: 0,
  maxTurns: 6,
  breath: 55,
  trust: 10,
  awareness: 5,
  agency: 3,
  finished: false,
  unread: 1
};

const worldLines = [
  "窗外竹影摇动，远处隐约传来贾府为喜事奔走的声音。火盆尚未燃起，诗稿与旧帕静静放在案上。",
  "雪雁低头拨着炭火，火星细细亮起。紫鹃坐在床沿，替黛玉轻轻顺着气。",
  "旧帕被送入火中，帕角微微一卷，墨痕很快暗下去。",
  "黛玉将诗稿抱了片刻，终于一页页送进火里。紫鹃想拦，却扶着她的身子，来不及动。",
  "雪雁扑过去抢救，余下的不过几片残纸。灰落在砖地上，屋中一时静得只剩咳声。",
  "远处喜乐更近了些，潇湘馆里灯影低垂。她的气息渐弱，却仍看着你所在的方向。"
];

const daiyuLines = [
  "（她抬眼看你，惊疑未定。）\n\n你不是这府里的人。她们也像瞧不见你。你……究竟是何人？",
  "（她听见你的话，眼睫微微一颤。）\n\n若你真是我方才一念唤来的，便别急着劝我。先在这里听一听罢。",
  "（她望着火光，声音低得几乎被咳意压住。）\n\n这些旧物留着，也不过叫旁人随意说我。烧了，倒像还由得我自己做一回主。",
  "（她手指一松，纸页落入火中。）\n\n我不是只为一场婚事活过。我的诗，我的心，也曾明明白白在这世上来过。",
  "（她闭了闭眼，像是疲极，却仍勉强撑着。）\n\n你说后来有人懂我……这话太远了，我未必信。可这一刻，我愿听。",
  "（她望着你，唇边微微一动。）\n\n这一程，有人听见，便也够了。"
];

const endingText =
  "潇湘馆残灯渐暗，竹影仍在窗前。\n\n林黛玉仍在宝玉成亲之夜离世。\n\n只是这一回，她临去前听见了一个不属于此世的人唤她的名字。";

const el = {
  chat: document.querySelector("#chatFlow"),
  input: document.querySelector("#playerInput"),
  send: document.querySelector("#sendButton"),
  statusLine: document.querySelector("#statusLine"),
  systemButton: document.querySelector("#systemButton"),
  systemBadge: document.querySelector("#systemBadge"),
  panel: document.querySelector("#systemPanel"),
  closePanel: document.querySelector("#closePanel"),
  panelStatus: document.querySelector("#panelStatus"),
  trustValue: document.querySelector("#trustValue"),
  awarenessValue: document.querySelector("#awarenessValue"),
  agencyValue: document.querySelector("#agencyValue")
};

function addMessage(kind, label, text) {
  const wrap = document.createElement("article");
  wrap.className = `message ${kind}`;

  const labelEl = document.createElement("div");
  labelEl.className = "label";
  labelEl.textContent = label;

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  wrap.append(labelEl, bubble);
  el.chat.append(wrap);
  el.chat.scrollTop = el.chat.scrollHeight;
}

function statusText() {
  return `子时｜剩余对话 ${Math.max(0, state.maxTurns - state.turn)}/${state.maxTurns}｜黛玉气息 ${state.breath}/100`;
}

function render() {
  el.statusLine.textContent = statusText();
  el.panelStatus.textContent = statusText();
  el.trustValue.textContent = state.trust;
  el.awarenessValue.textContent = state.awareness;
  el.agencyValue.textContent = state.agency;
  el.systemBadge.textContent = state.unread;
  el.systemBadge.classList.toggle("hidden", state.unread === 0);
}

function openPanel() {
  state.unread = 0;
  el.panel.classList.add("open");
  el.panel.setAttribute("aria-hidden", "false");
  render();
}

function closePanel() {
  el.panel.classList.remove("open");
  el.panel.setAttribute("aria-hidden", "true");
}

function handleInput() {
  const text = el.input.value.trim();
  if (!text || state.finished) return;
  el.input.value = "";

  addMessage("player", "你", text);
  state.turn += 1;
  state.breath = Math.max(0, state.breath - 8);
  state.trust = Math.min(100, state.trust + 5);
  state.awareness = Math.min(100, state.awareness + 4);
  state.agency = Math.min(100, state.agency + 3);

  const index = Math.min(state.turn - 1, worldLines.length - 1);
  addMessage("world", "世界", worldLines[index]);
  addMessage("daiyu", "林黛玉", state.breath <= 15 ? "（黛玉眼睫微动，似是听见了，却再无力答话。）" : daiyuLines[index]);

  if (state.turn >= state.maxTurns || state.breath <= 0) finish();
  render();
}

function finish() {
  state.finished = true;
  el.input.disabled = true;
  el.send.disabled = true;
  addMessage("world", "系统", endingText);
}

function init() {
  addMessage(
    "world",
    "玩家信息",
    "你在《红楼梦》卷末的空白页上，看见一行未干的新墨。\n\n下一刻，纸页自行翻动。你来到潇湘馆。"
  );
  addMessage(
    "world",
    "世界",
    "案上堆着几卷诗稿，旁边放着一方旧帕。一个披着绛色外衣的少女斜倚床榻，脸色极白，像已经等了很久。"
  );
  addMessage("daiyu", "林黛玉", "（她抬眼看向你，神情错愕而戒备。）\n\n你是……何人？");
  render();

  el.send.addEventListener("click", handleInput);
  el.input.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      handleInput();
    }
  });
  el.systemButton.addEventListener("click", openPanel);
  el.closePanel.addEventListener("click", closePanel);
}

init();
