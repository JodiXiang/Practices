# 入梦谣｜AI 黛玉对话游戏

这是基于《入梦谣・叙事策划案 V1.3》制作的纯前端文字对话原型。

## 运行

本地规则生成器可直接在浏览器打开：

```text
apps/daiyu-game/index.html
```

调用 DeepSeek 或其他 OpenAI-compatible 通用 Key 时请通过本地服务打开：

```bash
npm run dev -w apps/daiyu-game
```

然后访问：

```text
http://127.0.0.1:4173
```

在游戏右下角打开系统面板，填写：

- `Base URL`：例如 `https://api.deepseek.com`，或你的通用 Key 服务商兼容地址
- `API Key`：你的通用 Key
- `Model`：例如 `deepseek-chat`，或服务商提供的模型名

点击“保存模型设置”后，后续黛玉输出会优先调用该模型。未配置或请求失败时自动回退本地生成器。

也可以用环境变量设置默认值：

```bash
DEEPSEEK_API_KEY=你的_key
DEEPSEEK_MODEL=deepseek-chat
DEEPSEEK_BASE_URL=https://api.deepseek.com
PORT=4173
```

## 已实现

- 三方聊天流：玩家、林黛玉、世界消息
- 系统按钮与系统面板
- Trust / Awareness / Agency / 气息值
- 四阶段章节状态机
- 原著固定事件顺序
- 查看内心功能
- 黛玉禁用现代系统词的输出净化
- 固定死亡结局与可变临终心境
- DeepSeek 服务端调用接口，未配置 API Key 时自动回退本地生成器

## 后续接入真实 LLM

当前前端会优先请求 `server.mjs` 中的 `/api/daiyu/turn`。请求失败或未配置 API Key 时，`game.js` 中的 `generateTurn(input)` 会作为本地叙事生成器回退使用。
